fx_version "cerulean"
game "gta5"
lua54 "yes"

description "v-requirements on github"

client_scripts{
    "Client/Client*.lua",
} 

ui_page "html/Index.html"

files {
    "html/Index.html",
    "html/Script.js",
    "html/Style.css"
}
